﻿using Microsoft.Extensions.Options;
using System.Globalization;
using UnifiedUserSystem.src.Application.Options;

namespace UnifiedUserSystem.src.Api.Localization;

public sealed class RequestLocaleResolver : IRequestLocaleResolver
{
    public const string HttpContextItemKey = "UnifiedUserSystem.ResolvedLocale";

    private readonly LocalizationOptions _options;

    public RequestLocaleResolver(IOptions<LocalizationOptions> options)
    {
        _options = options.Value;
    }

    public string Resolve(HttpContext context)
    {
        if (context.Items.TryGetValue(HttpContextItemKey, out var cached) &&
            cached is string cachedLocale)
        {
            return cachedLocale;
        }

        var resolved = ResolveHeader(context.Request.Headers["Accept-Language"].ToString())
                       ?? _options.GetValidatedDefaultLocale();

        context.Items[HttpContextItemKey] = resolved;
        return resolved;
    }

    internal string? ResolveHeader(string? header)
    {
        if (string.IsNullOrWhiteSpace(header))
            return null;

        var candidates = new List<(string Locale, decimal Quality, int Position)>();
        var entries = header.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        for (var index = 0; index < entries.Length; index++)
        {
            var segments = entries[index].Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            var locale = segments[0];
            if (locale == "*")
                continue;

            var quality = 1m;
            foreach (var segment in segments.Skip(1))
            {
                if (!segment.StartsWith("q=", StringComparison.OrdinalIgnoreCase))
                    continue;

                if (!decimal.TryParse(segment[2..], NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out quality) ||
                    quality is < 0m or > 1m)
                {
                    quality = 0m;
                }
            }

            var supportedLocale = _options.NormalizeSupportedLocale(locale);
            if (supportedLocale is not null && quality > 0m)
                candidates.Add((supportedLocale, quality, index));
        }

        return candidates
            .OrderByDescending(x => x.Quality)
            .ThenBy(x => x.Position)
            .Select(x => x.Locale)
            .FirstOrDefault();
    }
}
