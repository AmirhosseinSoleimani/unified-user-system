﻿using UnifiedUserSystem.src.Application.Abstractions.Security;

namespace UnifiedUserSystem.src.UnifiedUserSystem.Infrastructure.Security
{
    public class BCryptPasswordHasher : IPasswordHasher
    {
        public string Hash(string password)
            => BCrypt.Net.BCrypt.HashPassword(password, workFactor: 10);


        public bool Verify(string password, string passwordHasd)
            => BCrypt.Net.BCrypt.Verify(password, passwordHasd);
    }
}
