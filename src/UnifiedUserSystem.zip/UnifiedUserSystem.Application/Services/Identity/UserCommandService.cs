﻿using UnifiedUserSystem.src.Application.Abstractions.Persistence;
using UnifiedUserSystem.src.Application.Abstractions.Security;
using UnifiedUserSystem.src.Application.Abstractions.Auditing;
using UnifiedUserSystem.src.Application.Abstractions.Services;
using UnifiedUserSystem.src.Application.Abstractions.Time;
using UnifiedUserSystem.src.Application.Services.Security;
using UnifiedUserSystem.src.Contracts.DTOs.Profile;
using UnifiedUserSystem.src.Contracts.DTOs.Users;
using UnifiedUserSystem.src.Domain.Common;
using UnifiedUserSystem.src.Domain.Identity.Entities;
using UnifiedUserSystem.src.Application.Validation;

namespace UnifiedUserSystem.src.Application.Services.Identity
{
    public class UserCommandService : IUserCommandService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IClock _clock;
        private readonly ICurrentUser _currentUser;
        private readonly IPasswordHasher _passwordHasher;
        private readonly IPasswordPolicy _passwordPolicy;
        private readonly IAuditLogWriter _auditLogWriter;
        private readonly IPermissionCacheInvalidator _permissionCacheInvalidator;

        public UserCommandService(
            IUnitOfWork unitOfWork,
            IClock clock,
            ICurrentUser currentUser,
            IPasswordHasher passwordHasher,
            IPasswordPolicy passwordPolicy,
            IAuditLogWriter auditLogWriter)
            : this(
                unitOfWork,
                clock,
                currentUser,
                passwordHasher,
                passwordPolicy,
                auditLogWriter,
                NullPermissionCacheInvalidator.Instance)
        {
        }

        public UserCommandService(
            IUnitOfWork unitOfWork,
            IClock clock,
            ICurrentUser currentUser,
            IPasswordHasher passwordHasher,
            IPasswordPolicy passwordPolicy,
            IAuditLogWriter auditLogWriter,
            IPermissionCacheInvalidator? permissionCacheInvalidator = null)
        {
            _unitOfWork = unitOfWork;
            _clock = clock;
            _currentUser = currentUser;
            _passwordHasher = passwordHasher;
            _passwordPolicy = passwordPolicy;
            _auditLogWriter = auditLogWriter;
            _permissionCacheInvalidator = permissionCacheInvalidator ?? NullPermissionCacheInvalidator.Instance;
        }

        public async Task DeactivateUserAsync(Guid id, CancellationToken ct = default)
        {
            var user = await _unitOfWork.Users.FindByIdAsync(id, ct);

            if (user is null)
                throw new KeyNotFoundException("User not found.");

            var wasActive = user.IsActive;

            user.Deactivate(_clock.Utcnow, _currentUser.UserId);

            if (wasActive && !user.IsActive)
            {
                await _auditLogWriter.WriteAsync(new WriteAuditLogRequest
                {
                    ActorUserId = _currentUser.UserId,
                    TargetUserId = user.Id,
                    EntityName = nameof(User),
                    EntityId = user.Id.ToString(),
                    Action = "UserDeactivated",
                    OldValues = new Dictionary<string, object?>
                    {
                        ["IsActive"] = true
                    },
                    NewValues = new Dictionary<string, object?>
                    {
                        ["IsActive"] = false
                    }
                }, ct);
            }

            await _unitOfWork.SaveChangesAsync(ct);
            await _permissionCacheInvalidator.InvalidateForUserAsync(user.Id, ct);
        }

        public async Task<ProfileResponse> UpdateUserAsync(
            Guid id,
            UpdateUserRequest req,
            CancellationToken ct = default)
        {
            if (req is null)
                throw new DomainException("Request is null.");

            var hasFirstName = !string.IsNullOrWhiteSpace(req.FirstName);
            var hasLastName = !string.IsNullOrWhiteSpace(req.LastName);
            var hasPhoneNumber = !string.IsNullOrWhiteSpace(req.PhoneNumber);
            var hasFullname = !string.IsNullOrWhiteSpace(req.Fullname);
            var hasUsername = !string.IsNullOrWhiteSpace(req.Username);
            var hasPassword = !string.IsNullOrWhiteSpace(req.Password);

            if (!hasFirstName && !hasLastName && !hasPhoneNumber && !hasFullname && !hasUsername && !hasPassword)
                throw new DomainException("At least one updatable field must be provided.");

            var user = await _unitOfWork.Users.FindByIdWithRolesAsync(id, ct);

            if (user is null)
                throw new KeyNotFoundException("User not found.");

            var now = _clock.Utcnow;
            var actorUserId = _currentUser.UserId;
            var oldValues = new Dictionary<string, object?>();
            var newValues = new Dictionary<string, object?>();

            var originalFullname = user.Fullname;
            var originalFirstName = user.FirstName;
            var originalLastName = user.LastName;
            var originalPhoneNumber = user.PhoneNumber;
            var originalUsername = user.Username;

            if (hasFirstName || hasLastName || hasPhoneNumber || hasFullname)
            {
                var nextFirstName = req.FirstName ?? user.FirstName;
                var nextLastName = req.LastName ?? user.LastName;

                if (hasFullname && (!hasFirstName || !hasLastName))
                {
                    var splitName = User.SplitFullName(req.Fullname!);
                    nextFirstName = hasFirstName ? nextFirstName : splitName.FirstName;
                    nextLastName = hasLastName ? nextLastName : splitName.LastName;
                }
                var nextPhoneNumber = req.PhoneNumber ?? user.PhoneNumber;


                user.ChangeProfile(nextFirstName, nextLastName, nextPhoneNumber, now, actorUserId);
            }

            if (hasUsername)
            {
                var normalizedUsername = User.NormalizeUsername(req.Username!);

                if (!string.Equals(user.Username, normalizedUsername, StringComparison.Ordinal))
                {
                    var usernameExists = await _unitOfWork.Users.UsernameExistsAsync(normalizedUsername);
                    if (usernameExists)
                        throw new InvalidOperationException("Username already exists.");
                }

                user.ChangeUsername(req.Username!, now, actorUserId);
            }

            if (hasPassword)
            {
                _passwordPolicy.Validate(req.Password!);

                var passwordHash = _passwordHasher.Hash(req.Password!);
                user.ChangePasswordHash(passwordHash, now, actorUserId);
            }

            if (!string.Equals(originalFullname, user.Fullname, StringComparison.Ordinal))
            {
                oldValues["Fullname"] = originalFullname;
                newValues["Fullname"] = user.Fullname;
            }

            if (!string.Equals(originalFirstName, user.FirstName, StringComparison.Ordinal))
            {
                oldValues["FirstName"] = originalFirstName;
                newValues["FirstName"] = user.FirstName;
            }

            if (!string.Equals(originalLastName, user.LastName, StringComparison.Ordinal))
            {
                oldValues["LastName"] = originalLastName;
                newValues["LastName"] = user.LastName;
            }

            if (!string.Equals(originalPhoneNumber, user.PhoneNumber, StringComparison.Ordinal))
            {
                oldValues["PhoneNumber"] = originalPhoneNumber;
                newValues["PhoneNumber"] = user.PhoneNumber;
            }

            if (!string.Equals(originalUsername, user.Username, StringComparison.Ordinal))
            {
                oldValues["Username"] = originalUsername;
                newValues["Username"] = user.Username;
            }

            if (hasPassword)
            {
                oldValues["PasswordChanged"] = false;
                newValues["PasswordChanged"] = true;
            }

            if (oldValues.Count > 0 || newValues.Count > 0)
            {
                await _auditLogWriter.WriteAsync(new WriteAuditLogRequest
                {
                    ActorUserId = actorUserId,
                    TargetUserId = user.Id,
                    EntityName = nameof(User),
                    EntityId = user.Id.ToString(),
                    Action = "UserUpdated",
                    OldValues = oldValues,
                    NewValues = newValues
                }, ct);
            }

            await _unitOfWork.SaveChangesAsync(ct);

            var roles = user.UserRoles
                .Where(x => x.Role != null)
                .Select(x => x.Role.Name)
                .Distinct()
                .ToArray();

            return new ProfileResponse
            {
                Id = user.Id,
                Email = user.Email,
                Username = user.Username,
                FirstName = user.FirstName,
                LastName = user.LastName,
                PhoneNumber = user.PhoneNumber,
                Fullname = user.Fullname,
                IsActive = user.IsActive,
                Roles = roles
            };
        }
    }
}