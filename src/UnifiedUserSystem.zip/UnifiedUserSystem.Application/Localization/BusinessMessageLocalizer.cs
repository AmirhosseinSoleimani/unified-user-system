﻿using System.Globalization;
using UnifiedUserSystem.src.Application.Abstractions.Localization;
using UnifiedUserSystem.src.Domain.Common;

namespace UnifiedUserSystem.src.Application.Localization;

public sealed class BusinessMessageLocalizer : IBusinessMessageLocalizer
{
    private const string MissingEnglish = "The requested operation could not be completed.";
    private const string MissingPersian = "انجام عملیات درخواستی ممکن نیست.";

    private static readonly IReadOnlyDictionary<string, IReadOnlyDictionary<string, string>> Catalog =
        new Dictionary<string, IReadOnlyDictionary<string, string>>(StringComparer.OrdinalIgnoreCase)
        {
            ["en-US"] = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                [BusinessErrorCodes.UserNotFound] = "User was not found.",
                [BusinessErrorCodes.InvalidCredentials] = "The username or password is invalid.",
                [BusinessErrorCodes.EmailAlreadyExists] = "An account with this email address already exists.",
                [BusinessErrorCodes.UsernameAlreadyExists] = "An account with this username already exists.",
                [BusinessErrorCodes.PasswordPolicyViolation] = "The password does not meet the policy requirements.",
                [BusinessErrorCodes.UserInactive] = "The user account is inactive.",
                [BusinessErrorCodes.InvalidPreferredLocale] = "The selected locale '{locale}' is not supported.",
                [BusinessErrorCodes.ValidationFailed] = "The value for '{field}' is invalid.",
                [BusinessErrorCodes.UnexpectedError] = "An unexpected error occurred."
            },
            ["fa-IR"] = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                [BusinessErrorCodes.UserNotFound] = "کاربر یافت نشد.",
                [BusinessErrorCodes.InvalidCredentials] = "نام کاربری یا گذرواژه نامعتبر است.",
                [BusinessErrorCodes.EmailAlreadyExists] = "حسابی با این نشانی ایمیل از قبل وجود دارد.",
                [BusinessErrorCodes.UsernameAlreadyExists] = "حسابی با این نام کاربری از قبل وجود دارد.",
                [BusinessErrorCodes.PasswordPolicyViolation] = "گذرواژه با الزامات امنیتی سازگار نیست.",
                [BusinessErrorCodes.UserInactive] = "حساب کاربری غیرفعال است.",
                [BusinessErrorCodes.InvalidPreferredLocale] = "زبان انتخاب‌شده '{locale}' پشتیبانی نمی‌شود.",
                [BusinessErrorCodes.ValidationFailed] = "مقدار '{field}' نامعتبر است.",
                [BusinessErrorCodes.UnexpectedError] = "خطای غیرمنتظره‌ای رخ داد."
            }
        };

    public string Localize(string code, string locale, IReadOnlyDictionary<string, object?>? parameters = null)
    {
        locale = Catalog.ContainsKey(locale) ? locale : "fa-IR";
        var messages = Catalog[locale];
        var template = messages.TryGetValue(code, out var value)
            ? value
            : locale.Equals("en-US", StringComparison.OrdinalIgnoreCase) ? MissingEnglish : MissingPersian;

        if (parameters is null || parameters.Count == 0) return template;
        foreach (var parameter in parameters)
            template = template.Replace("{" + parameter.Key + "}", Convert.ToString(parameter.Value, CultureInfo.InvariantCulture));
        return template;
    }
}

