﻿using UnifiedUserSystem.src.Application.Abstractions.Localization;

namespace UnifiedUserSystem.src.Application.Localization;

public sealed class RequestLocale(string locale) : IRequestLocale
{
    public string Locale { get; } = locale;
}
