﻿using Microsoft.Extensions.Options;
using UnifiedUserSystem.src.Application.Abstractions.Localization;
using UnifiedUserSystem.src.Application.Options;

namespace UnifiedUserSystem.src.Application.Localization;

public sealed class AcceptLanguageLocaleResolver : IRequestLocaleResolver
{
    private readonly LocalizationOptions _options;
    private readonly Dictionary<string, string> _aliases;

    public AcceptLanguageLocaleResolver(IOptions<LocalizationOptions> options)
    {
        _options = options.Value;
        _aliases = new(StringComparer.OrdinalIgnoreCase)
        {
            ["fa"] = _options.PersianLocale,
            ["fa-IR"] = _options.PersianLocale,
            ["en"] = _options.EnglishLocale,
            ["en-US"] = _options.EnglishLocale
        };
    }

    public string Resolve(string? acceptLanguageHeader)
    {
        if (string.IsNullOrWhiteSpace(acceptLanguageHeader)) return _options.DefaultLocale;

        try
        {
            var candidates = acceptLanguageHeader.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select((part, index) => Parse(part, index))
                .Where(x => x.Quality > 0)
                .OrderByDescending(x => x.Quality)
                .ThenBy(x => x.Index);

            foreach (var candidate in candidates)
            {
                if (_aliases.TryGetValue(candidate.Tag, out var exact) && IsSupported(exact)) return exact;
                var neutral = candidate.Tag.Split('-')[0];
                if (_aliases.TryGetValue(neutral, out var normalized) && IsSupported(normalized)) return normalized;
            }
        }
        catch
        {
            return _options.DefaultLocale;
        }

        return _options.DefaultLocale;
    }

    private bool IsSupported(string locale) => _options.SupportedLocales.Contains(locale, StringComparer.OrdinalIgnoreCase);

    private static (string Tag, decimal Quality, int Index) Parse(string part, int index)
    {
        var pieces = part.Split(';', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
        var q = 1m;
        foreach (var p in pieces.Skip(1))
        {
            if (p.StartsWith("q=", StringComparison.OrdinalIgnoreCase) && decimal.TryParse(p[2..], out var parsed)) q = parsed;
        }
        return (pieces[0], q, index);
    }
}
