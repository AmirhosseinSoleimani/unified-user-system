﻿
using Microsoft.Extensions.Options;
using UnifiedUserSystem.src.Application.Options;

namespace UnifiedUserSystem.src.Application.Localization;

public sealed class LocalizationOptionsValidator : IValidateOptions<LocalizationOptions>
{
    public ValidateOptionsResult Validate(string? name, LocalizationOptions options)
    {
        if (options.SupportedLocales.Length == 0) return ValidateOptionsResult.Fail("At least one locale must be supported.");
        if (!options.SupportedLocales.Contains(options.DefaultLocale)) return ValidateOptionsResult.Fail("DefaultLocale must be supported.");
        if (!options.SupportedLocales.Contains(options.PersianLocale)) return ValidateOptionsResult.Fail("PersianLocale must be supported.");
        if (!options.SupportedLocales.Contains(options.EnglishLocale)) return ValidateOptionsResult.Fail("EnglishLocale must be supported.");
        return ValidateOptionsResult.Success;
    }
}