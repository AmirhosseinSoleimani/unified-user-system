﻿namespace UnifiedUserSystem.src.Application.Abstractions.Security;

public interface IPasswordHasher
{
    string Hash(string password);
    bool Verify(string password, string passwordHasd);
}
