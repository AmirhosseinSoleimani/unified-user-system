﻿
namespace UnifiedUserSystem.src.Application.Options;

public sealed class GeoIpOptions
{
    public const string SectionName = "GeoIp";
    public bool Enabled { get; set; } = true;
    public string FailureFallbackLocale { get; set; } = "fa-IR";
}
