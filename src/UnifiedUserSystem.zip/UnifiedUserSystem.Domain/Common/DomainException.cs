﻿namespace UnifiedUserSystem.src.Domain.Common;

public class DomainException : Exception, ICodedBusinessException
{
    public DomainException(string legacyMessage) 
        : base(legacyMessage)
    {
        Code = DomainErrorCodes.DomainError;
        Parameters = EmptyParameters;
        LegacyFallbackMessage = legacyMessage;
    }

    private DomainException(
        string code,
        IReadOnlyDictionary<string, object?>? parameters,
        Exception? innerException)
        : base(BusinessExceptionDiagnostics.Build(code, parameters), innerException)
    {
        if (string.IsNullOrWhiteSpace(code))
            throw new ArgumentException("A domain error code is required.", nameof(code));

        Code = code.Trim();
        Parameters = parameters ?? EmptyParameters;
    }

    public string Code { get; }

    public IReadOnlyDictionary<string, object?> Parameters { get; }

    public string? LegacyFallbackMessage { get; }

    public static DomainException For(
        string code,
        IReadOnlyDictionary<string, object?>? parameters = null,
        Exception? innerException = null)
        => new(code, parameters, innerException);

    private static IReadOnlyDictionary<string, object?> EmptyParameters { get; }
        = new Dictionary<string, object?>();
}
