﻿
namespace UnifiedUserSystem.src.Domain.Common;

public static class BusinessErrorCodes
{
    public const string UserNotFound = "USER_NOT_FOUND";
    public const string InvalidCredentials = "INVALID_CREDENTIALS";
    public const string EmailAlreadyExists = "EMAIL_ALREADY_EXISTS";
    public const string UsernameAlreadyExists = "USERNAME_ALREADY_EXISTS";
    public const string PasswordPolicyViolation = "PASSWORD_POLICY_VIOLATION";
    public const string UserInactive = "USER_INACTIVE";
    public const string InvalidPreferredLocale = "INVALID_PREFERRED_LOCALE";
    public const string ValidationFailed = "VALIDATION_FAILED";
    public const string UnexpectedError = "UNEXPECTED_ERROR";
}